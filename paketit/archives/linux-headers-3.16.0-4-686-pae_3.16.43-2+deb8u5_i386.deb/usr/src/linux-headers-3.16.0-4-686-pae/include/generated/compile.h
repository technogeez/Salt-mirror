/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 SMP Debian 3.16.43-2+deb8u5 (2017-09-19)"
#define LINUX_COMPILE_BY "debian-kernel"
#define LINUX_COMPILE_HOST "lists.debian.org"
#define LINUX_COMPILER "gcc version 4.8.4 (Debian 4.8.4-1) "
