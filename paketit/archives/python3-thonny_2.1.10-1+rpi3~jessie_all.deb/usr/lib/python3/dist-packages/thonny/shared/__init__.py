# Frontend will interpret this folder as thonny.shared
# For backend this folder will be in path