
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.12.1'
version = '1.12.1'
full_version = '1.12.1'
git_revision = '11f77c8b19dae99981910695a806cbf4def67e24'
release = True

if not release:
    version = full_version
