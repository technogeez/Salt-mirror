package perlfaq;
{
  $perlfaq::VERSION = '5.0150044';
}

0; # not is it supposed to be loaded
